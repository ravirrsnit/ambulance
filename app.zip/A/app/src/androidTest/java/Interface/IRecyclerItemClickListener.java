package Interface;

import android.view.View;

public interface IRecyclerItemClickListener {
    void onItemClickListener(View view, int position);
}
