package Utils;

import Model.User;

public class Common {
    public static final String USER_INFORMATION="UserInformation";
    public static final String USER_UID_SAVE_KEY = "SaveUid" ;
    public static final String TOKENS ="Tokens" ;
    public static User loggedUser;
}
