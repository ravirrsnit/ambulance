package com.example.app;

import android.view.MenuItem;

public interface home_activity {
    boolean OnNavigationItemSelected(MenuItem item);
}
